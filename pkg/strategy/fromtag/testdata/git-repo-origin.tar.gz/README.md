fake repo

current version: 2.0.0
next version: 2.1.0

